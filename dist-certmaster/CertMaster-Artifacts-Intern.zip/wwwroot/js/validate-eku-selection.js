$(function () {
    $(document).ready(function () {
        $('input[type=checkbox]').change(function () {
            if ($('input[type=checkbox]:checked').length > 0) {
                $('#ExtendedKeyUsageList-error').addClass('d-none');
            }
        });

        $('button[type="submit"]').click(function () {
            if ($('input[type=checkbox]:checked').length === 0) {
                $('#ExtendedKeyUsageList-error').removeClass('d-none');
                $(this).parents('form').valid();
                return false;
            }
            else if ($('input[type=checkbox]:checked').length > 0) {
                $('#ExtendedKeyUsageList-error').addClass('d-none');
            }
        });
    });
}(jQuery));